(function() {
    'use strict';

    angular
        .module('mitchapp')
        .controller('LoginController', LoginController);

    LoginController.$inject = [
      '$state',
      '$firebaseArray'
    ];

    /* @ngInject */
    function LoginController(
      $state,
      $firebaseArray
    ) {

        var vm = this;
        vm.login = login;
        vm.user = undefined;
        vm.error = {
          show: false,
          msj: ''
        };

        var ref = new Firebase('https://just-buy-bd2.firebaseio.com').child("tcliente");
        vm.messages = $firebaseArray(ref)

        //LOAD
        vm.list = $firebaseArray(ref);
        vm.list.$loaded()
          .then(function(x) {
            x === vm.list; // true
          })
          .catch(function(error) {
            console.log("Error:", error);
          });

          console.log("LISTA, ", vm.list);
          

        //ADD
        console.log("MENSAJE:   ",vm.messages);
        vm.messages.$add({ user:"pruebas generales", pass: "2393"}).then(function(ref) {
          var id = ref.key();
          console.log("added record with id " + id);
          console.log("Dentro del add:   ",vm.messages);
          //vm.messages.$indexFor(id); // returns location in the array
        });

        // vm.messages.$add({
        //   user: false,
        //   pass: false
        // });
        console.log("Lo ultimo", vm.messages);
        activate();

        function activate () {
          console.log("ente en LoginController");
        }

        function login () {
          console.log("Iniciar Sesion");
          $state.go('producto');
        }

        // function login () {
        //   console.log("el usuario a logearse es ", vm.user);
        //
        //   if (vm.user.rol === 'user') {
        //
        //     storage.setUser(vm.user);
        //     $state.go('project.list');
        //
        //   } else if (vm.user.rol === 'admin') {
        //
        //     storage.setUser(vm.user);
        //     $state.go('admin');
        //
        //   } else {
        //
        //     vm.user = {};
        //     vm.error = {
        //       show: true,
        //       msj: 'Usuario invalido'
        //     };
        //
        //   }
        // }

    }
})();
