comandos que corro para agregar funcionalidades


Para agregar copy file con bower
$ npm install gulp run-sequence main-bower-files gulp-inject --save-dev


paquetes usados para inyectar los archivos con gulp
https://www.npmjs.com/package/gulp-inject --> Archivos de un arreglo
https://www.npmjs.com/package/main-bower-files --> Archivos bower


otros paquetes
https://www.npmjs.com/package/run-sequence --> correr tareas en secuencia
https://www.npmjs.com/package/gulp-angular-filesort --> para agregar proyectos con estructura de google!
